import Product from "../../models/product.js";

//Create Product
const createProduct = async (req, res) => {
    const { productName, productDescription, productPrice, productQty} = req.body;
    const product = await Product.findOne({ productName: productName });
    if (product) {
      res.send({ status: "failed", message: "Product Already Exists.....Please Enter Different Product" });
    } else {
      if (productName && productDescription && productPrice && productQty) {
        try {
          const product = await Product.create(req.body);
          res.json(product);
        } catch (error) {
          res.json(error);
        }
      } else {
        res.send({ status: "failed", message: "All Field Are Required" });
      }
    }
  };
  
  
  export default createProduct;