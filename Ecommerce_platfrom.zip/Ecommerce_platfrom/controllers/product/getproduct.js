import Product from "../../models/product.js";

//Display Product By Id
const getProductById = async (req, res) => {
    try {
      const { id } = req.params;
      const product = await Product.findById(id)
      if (!product) {
        return res.json("product not found!");
      }
      res.json(product);
    } catch (error) {
      res.json(error);
    }
  };
  
  export default getProductById;