import Product from "../../models/product.js";

//Display Product
const getProduct = async (req,res) =>{
    try {
        const product = await Product.find({})
        if(!product){
            return res.json('Product not found!')
        }
        res.json(product)
    } catch (error) {
        res.json(error)
    }
}

export default getProduct