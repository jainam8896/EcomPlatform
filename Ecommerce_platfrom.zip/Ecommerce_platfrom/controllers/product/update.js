import Product from "../../models/product.js";

//Update Product
const updateProduct = async(req,res) => {
    try {
        const {id} = req.params;
        const product = await Product.findByIdAndUpdate(id,req.body)
        if(!product){
            return res.json({message: `Product id ${id} is Invalid`})
        }
        res.json({message: `Product Updated Successfully`})
        const updateProduct = await Product.findById(id)
        res.json(updateProduct)
    } catch (error) {
        res.json(error)
    }
}

export default updateProduct