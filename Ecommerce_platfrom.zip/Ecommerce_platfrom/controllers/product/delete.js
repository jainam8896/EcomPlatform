import Product from "../../models/product.js";

//Delete Product
const deletProduct = async (req,res) => {
    try {
        const { id } = req.params
        const product = await Product.findByIdAndDelete(id)
        if (!product) {
            return res.json('Product not found!')
        }
        res.json("Product Deleted Successfully")
    } catch (error) {
        res.json(error.message);
    }
}

export default deletProduct