import User from "../../models/User.js";
import bcrypt from "bcrypt";

//User Can Change Password
const changePassword = async (req, res) => {
  try {
    const { oldPassword, newPassword, password_confirmation } = req.body;
    if (oldPassword && newPassword && password_confirmation) {
      if (newPassword !== password_confirmation) {
        return res.send({status: "failed", message: "New Password And Confirm password Do not match",});
      }
      const user = await User.findById(req.user._id);
      if (!user) {
        return res.send({ status: "failed", message: "User Not Found" });
      }
      const match = await bcrypt.compare(oldPassword, user.password);
      if (!match) {
        return res.send({ status: "failed", message: "Invalid Old Password" });
      }
      const salt = await bcrypt.genSalt(10);
      const newHashedPassword = await bcrypt.hash(newPassword, salt);
      await User.findByIdAndUpdate(req.user._id, { $set: { password: newHashedPassword }});
      return res.send({status: "success", message: "Password Changed Successfully",});
    } else {
      return res.send({ status: "failed", message: "All failed Are Require" });
    }
  } catch (error) {
    console.error(error);
    return res.send({ status: "error", message: "Internal Server Error" });
  }
};

export default changePassword;
