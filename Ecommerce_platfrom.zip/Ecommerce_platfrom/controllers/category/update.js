import Category from "../../models/Category.js";

//Update category
const updateCategory = async(req,res) => {
    try {
        const {id} = req.params;
        const category = await Category.findByIdAndUpdate(id,req.body)
        if(!category){
            return res.json({message: `Category id ${id} is Invalid`})
        }
        res.json({message: `Category Updated Successfully`})
        const updateCategory = await Category.findById(id)
        res.json(updateCategory)
    } catch (error) {
        res.json(error)
    }
}

export default updateCategory