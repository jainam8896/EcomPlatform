import Category from "../../models/Category.js"

//Display category
const getCategory = async (req,res) =>{
    try {
        const category = await Category.find({})
        if(!category){
            return res.json('Category not found!')
        }
        res.json(category)
    } catch (error) {
        res.json(error)
    }
}

export default getCategory