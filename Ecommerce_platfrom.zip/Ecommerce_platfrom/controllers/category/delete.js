import Category from "../../models/Category.js";

//Delete Category
const deletcategory = async (req,res) => {
    try {
        const { id } = req.params
        const category = await Category.findByIdAndDelete(id)
        if (!category) {
            return res.json('Category is not found!')
        }
        res.json("Category Deleted Successfully")
    } catch (error) {
        res.json(error.message);
    }
}

export default deletcategory