import Category from "../../models/Category.js";

//display category Root
const getCategoryRoot = async (req, res) => {
  try {
    const { id } = req.params;
    // const user = await User.findById(id).populate([{path: 'parentId',select:'name'},{path: 'parentId',select:'name'}])
    //  const category = await Category.findById(id).populate('parentId')

    //  const category = await Category.findById(id).populate([{path: 'parentId',
    //populate:[{path: 'parentId',populate:[{path: 'parentId',populate:[{path: 'parentId',populate:[{path: 'parentId',}]}]}]}]}])
    
    const category = await Category.findById(id)
    if (!category) {
      return res.json("Category not found!");
    }
    res.json(category);
  } catch (error) {
    res.json(error);
  }
};

export default getCategoryRoot;
