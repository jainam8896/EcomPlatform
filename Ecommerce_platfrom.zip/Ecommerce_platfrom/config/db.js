import mongoose from "mongoose";

const connectDB = async(DATABASE_URL) => {
    try {
        const db = {dbname: process.env.DB_NAME};
        await mongoose.connect(DATABASE_URL,db);
        console.log('Database Connected Successfully');
    } catch (error) {
        console.log('Database Noe Connected');
    }
}

export default connectDB