import  mongoose  from "mongoose";
import autopopulate from 'mongoose-autopopulate'

const categorySchema = new mongoose.Schema({
    name:{
        type: String,
        required:true
    },
    parentId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Category',
        default:null,
        autopopulate:true
    }
},{timestamps:true})

categorySchema.plugin(autopopulate)

const Category = mongoose.model('Category',categorySchema)
export default Category