import 'dotenv/config'
import express from 'express'
import connectDB from './config/db.js'
import userRoute from './routes/user.js'
import categoryRoute from './routes/category.js'
import productRoute from './routes/product.js'

const app = express()
const port = process.env.PORT
const DATABASE_URL = process.env.DATABASE_URL

connectDB(DATABASE_URL)

app.use(express.json())
app.use('/',userRoute)
app.use('/',categoryRoute)
app.use('/',productRoute)

app.listen(port,()=>{
    console.log(`Server Running on Port ${port}`);
})
