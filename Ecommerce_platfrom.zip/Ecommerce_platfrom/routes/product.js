import express from 'express'
const productRoute = express.Router()
import createProduct from '../controllers/product/create.js'
import deletProduct from '../controllers/product/delete.js'
import getProduct from '../controllers/product/display.js'
import updateProduct from '../controllers/product/update.js'
import getProductById from '../controllers/product/getproduct.js'

productRoute.post('/api/createproduct',createProduct)
productRoute.delete('/api/deleteproduct/:id',deletProduct)
productRoute.get('/api/getproduct',getProduct)
productRoute.put('/api/updateproduct/:id',updateProduct)
productRoute.get('/api/getproductbyid/:id',getProductById)

export default productRoute