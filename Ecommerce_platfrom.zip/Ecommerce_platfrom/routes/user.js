import express from 'express'
const userRoute = express.Router()
import userRegistration from '../controllers/user/signup.js'
import userLogin from '../controllers/user/login.js'
import changePassword from '../controllers/user/changepassword.js'
import checkUserAuth from '../middleware/auth-middleware.js'
import forgetPassword from '../controllers/user/forgetpassword.js'
import userPasswordReset from '../controllers/user/resetpassword.js'
import deletUser from '../controllers/user/deleteuser.js'

//Auth-Middleware
// router.use('/api/changepassword',checkUserAuth)

//Public Route
userRoute.post('/api/register',userRegistration)
userRoute.post('/api/login',userLogin)
userRoute.post('/api/forget-Password',forgetPassword)
userRoute.post('/api/reset-password/:id/:token',userPasswordReset)
userRoute.delete('/api/deleteuser/:id',deletUser)

//Protected Route
userRoute.post('/api/changepassword',checkUserAuth,changePassword)

export default userRoute