import express from 'express'
const categoryRoute = express.Router()
import createCategory from '../controllers/category/create.js'
import getCategory from '../controllers/category/display.js'
import getCategoryRoot from '../controllers/category/getcategory.js'
import deletcategory from '../controllers/category/delete.js'
import updateCategory from '../controllers/category/update.js'

categoryRoute.post('/api/createcategory',createCategory)
categoryRoute.get('/api/getcategory',getCategory)
categoryRoute.get('/api/getcategory-root/:id',getCategoryRoot)
categoryRoute.delete('/api/deletecategory/:id',deletcategory)
categoryRoute.put('/api/updatecategory/:id',updateCategory)

export default categoryRoute